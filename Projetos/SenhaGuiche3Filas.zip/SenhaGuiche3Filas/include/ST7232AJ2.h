/* ST7232AJ2.h */
#ifdef MCU_NAME
#define ST7232AJ2 1
#endif
#include "ST7232A.h"
