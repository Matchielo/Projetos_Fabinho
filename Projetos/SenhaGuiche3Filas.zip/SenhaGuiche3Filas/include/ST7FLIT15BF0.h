/* ST7FLIT15BF0.h */
#ifdef MCU_NAME
#define ST7FLIT15BF0 1
#endif
#include "ST7LITE15B.h"
