/* ST72F32AK1.h */
#ifdef MCU_NAME
#define ST72F32AK1 1
#endif
#include "ST7232A.h"
