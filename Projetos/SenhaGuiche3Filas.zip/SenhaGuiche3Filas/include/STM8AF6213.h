/* STM8AF6213.h */
#ifdef MCU_NAME
#define STM8AF6213 1
#endif
#include "STM8AF6223.h"
