/* STM8AF6223PxA.h */
#ifdef MCU_NAME
#define STM8AF6223PxA 1
#endif
#include "STM8AF6223.h"
