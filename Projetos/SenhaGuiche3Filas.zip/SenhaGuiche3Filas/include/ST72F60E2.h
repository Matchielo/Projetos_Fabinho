/* ST72F60E2.h */
#ifdef MCU_NAME
#define ST72F60E2 1
#endif
#include "ST7260.h"
