/* ST7FMC2S7.h */
#ifdef MCU_NAME
#define ST7FMC2S7 1
#endif
#include "ST7FMC2S6.h"
