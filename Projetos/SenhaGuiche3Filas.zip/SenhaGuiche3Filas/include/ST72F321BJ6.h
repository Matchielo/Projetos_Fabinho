/* ST72F321BJ6.h */
#ifdef MCU_NAME
#define ST72F321BJ6 1
#endif
#include "ST72321.h"
