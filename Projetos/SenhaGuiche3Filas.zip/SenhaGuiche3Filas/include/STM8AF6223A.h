/* STM8AF6223A.h */
#ifdef MCU_NAME
#define STM8AF6223A 1
#endif
#include "STM8AF6223.h"
