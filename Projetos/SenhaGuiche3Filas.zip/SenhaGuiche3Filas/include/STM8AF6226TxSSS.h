/* STM8AF6226TxSSS.h */
#ifdef MCU_NAME
#define STM8AF6226TxSSS 1
#endif
#include "STM8AF61x6.h"
