/* STM8AF5178.h */
#ifdef MCU_NAME
#define STM8AF5178 1
#endif
#include "STM8AF51x8.h"
