/* ST72F324LK4.h */
#ifdef MCU_NAME
#define ST72F324LK4 1
#endif
#include "ST72324.h"
