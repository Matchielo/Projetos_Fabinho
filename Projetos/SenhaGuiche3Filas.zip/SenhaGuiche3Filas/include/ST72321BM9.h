/* ST72321BM9.h */
#ifdef MCU_NAME
#define ST72321BM9 1
#endif
#include "ST72F321M6.h"
