/* STM8AF52A6.h */
#ifdef MCU_NAME
#define STM8AF52A6 1
#endif
#include "STM8AF51x6.h"
