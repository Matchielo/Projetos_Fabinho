/* ST72321_A_R9.h */
#ifdef MCU_NAME
#define ST72321_A_R9 1
#endif
#include "ST72321.h"
