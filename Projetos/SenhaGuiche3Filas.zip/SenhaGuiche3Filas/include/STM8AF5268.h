/* STM8AF5268.h */
#ifdef MCU_NAME
#define STM8AF5268 1
#endif
#include "STM8AF51x8.h"
