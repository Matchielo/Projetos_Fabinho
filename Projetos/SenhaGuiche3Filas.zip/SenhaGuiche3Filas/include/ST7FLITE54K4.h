/* ST7FLITE54K4.h */
#ifdef MCU_NAME
#define ST7FLITE54K4 1
#endif
#include "ST72344.h"
