/* ST72325J6.h */
#ifdef MCU_NAME
#define ST72325J6 1
#endif
#include "ST72325.h"
