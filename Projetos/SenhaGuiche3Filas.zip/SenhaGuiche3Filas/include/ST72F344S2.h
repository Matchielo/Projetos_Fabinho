/* ST72F344S2.h */
#ifdef MCU_NAME
#define ST72F344S2 1
#endif
#include "ST72344.h"
