/* ST7FLIT19BY1.h */
#ifdef MCU_NAME
#define ST7FLIT19BY1 1
#endif
#include "ST7LITE19B.h"
