/* ST72_F_361J6.h */
#ifdef MCU_NAME
#define ST72_F_361J6 1
#endif
#include "ST72361AR.h"
