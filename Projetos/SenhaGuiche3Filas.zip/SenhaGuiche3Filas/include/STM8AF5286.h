/* STM8AF5286.h */
#ifdef MCU_NAME
#define STM8AF5286 1
#endif
#include "STM8AF51x6.h"
