/* ST72F32AK2.h */
#ifdef MCU_NAME
#define ST72F32AK2 1
#endif
#include "ST7232A.h"
