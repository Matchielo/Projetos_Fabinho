/* ST7263BE6.h */
#ifdef MCU_NAME
#define ST7263BE6 1
#endif
#include "ST7263BE.h"
