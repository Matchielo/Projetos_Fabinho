/* ST72_F_361K9.h */
#ifdef MCU_NAME
#define ST72_F_361K9 1
#endif
#include "ST72361K.h"
