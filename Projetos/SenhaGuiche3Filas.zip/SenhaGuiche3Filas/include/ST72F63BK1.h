/* ST72F63BK1.h */
#ifdef MCU_NAME
#define ST72F63BK1 1
#endif
#include "ST7263BK1.h"
