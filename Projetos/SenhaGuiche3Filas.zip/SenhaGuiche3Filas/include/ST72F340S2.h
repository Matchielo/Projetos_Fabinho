/* ST72F340S2.h */
#ifdef MCU_NAME
#define ST72F340S2 1
#endif
#include "ST72340.h"
