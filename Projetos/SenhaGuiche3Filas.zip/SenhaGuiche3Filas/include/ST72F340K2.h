/* ST72F340K2.h */
#ifdef MCU_NAME
#define ST72F340K2 1
#endif
#include "ST72340.h"
