/* ST72F321BLJ6.h */
#ifdef MCU_NAME
#define ST72F321BLJ6 1
#endif
#include "ST72321.h"
