/* ST7FLIT19BF0.h */
#ifdef MCU_NAME
#define ST7FLIT19BF0 1
#endif
#include "ST7LITE19B.h"
