/* ST72321R6.h */
#ifdef MCU_NAME
#define ST72321R6 1
#endif
#include "ST72321.h"
