/* ST72F324LK2.h */
#ifdef MCU_NAME
#define ST72F324LK2 1
#endif
#include "ST72324.h"
